reed make mod

you play mod

mod has:
- infinite sprint
- keep one scrap type when everyone dies
- shovel make boing sound


ZIP_INPUT_FOLDER="..\..\..\zip_these\";
ZIP_OUTPUT_FOLDER="..\..\..\";
copy "$(TargetName).dll" "..\..\..\zip_these\$(TargetName).dll";

if exist "..\..\..\$(AssemblyName).zip" (  Del "..\..\..\$(AssemblyName).zip");

powershell.exe -command Compress-Archive -Path "..\..\..\zip_these\$(AssemblyName).dll", ""..\..\..\zip_these\package.json" -DestinationPath "..\..\..\$(AssemblyName).zip";