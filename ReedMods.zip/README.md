reed make mod

[you play mod](https://thunderstore.io/c/lethal-company/p/reeddoesstuff/ReedMods/)

mod has:
- infinite sprint
- keep one scrap type when everyone dies
- shovel make boing sound
